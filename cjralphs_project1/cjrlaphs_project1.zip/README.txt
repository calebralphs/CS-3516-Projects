Caleb Ralphs
CS 3516 Project 1

To compile the program:
  1. cd into project folder
  2. type 'make' into the command line

To connect the client:
  1. cd into project folder
  2. type './client [option] url port' into the command line

To connect the server:
    1. cd into project folder
    2. type './client port' into the command line
